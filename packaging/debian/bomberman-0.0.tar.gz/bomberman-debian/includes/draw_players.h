#ifndef _DRAW_PLAYER_H_
#define _DRAW_PLAYER_H_

int	draw_players(void *arg, t_game_info *client_game_info);
int	draw_player(void *arg, t_player_info player);

#endif /* !_DRAW_PLAYER_H_ */
