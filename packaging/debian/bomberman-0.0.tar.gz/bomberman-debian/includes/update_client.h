#include "game_info.h"
#include "server_request.h"

void update_pos(t_game_info **game_info, t_response_pool *response_pool);
void update_bomb(t_game_info **game_info, t_response_pool *response_pool);
void update_players(t_game_info **game_info, t_response_pool *response_pool);
void update_explosion(t_game_info **game_info, t_response_pool *response_pool);
