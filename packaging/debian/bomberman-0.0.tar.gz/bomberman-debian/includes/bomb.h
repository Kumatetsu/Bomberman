#ifndef _BOMB_H_
#define _BOMB_H_

#include "server.h"

t_map_destroyable *place_bomb(t_srv **server, int id_player, int linked_index[1]);

#endif /* !_BOMB_H_ */
