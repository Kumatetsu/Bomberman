/*
** my_put.h for Project-Master in /home/enach/CLionProjects/Bomberman
**
** Made by hochar_n
** Login   <hochar_n@etna-alternance.net>
**
** Started on  Thu Jul  5 21:37:42 2018 hochar_n
** Last update Thu Jul  5 21:37:43 2018 hochar_n
*/

#ifndef  _MY_PUT_H_
# define _MY_PUT_H_

void my_putchar(char c);
void my_putstr(char *str);

#endif  /* !_MY_PUT_H_ */
