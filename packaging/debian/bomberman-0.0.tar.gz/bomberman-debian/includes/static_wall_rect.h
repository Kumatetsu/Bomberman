#ifndef _STATIC_WALL_RECT_H_
#define _STATIC_WALL_RECT_H_

#include "sdl.h"

SDL_Rect	*get_walls();
void		init_wall_rect();

#endif
