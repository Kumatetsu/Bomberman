#ifndef _RESPONSE_TYPE_UTILS_H_
#define _RESPONSE_TYPE_UTILS_H_


int define_response_type(int command);

#endif
