/*
** menu.h for Project-Master in /home/enach/CLionProjects/Bomberman
**
** Made by hochar_n
** Login   <hochar_n@etna-alternance.net>
**
** Started on  Thu Jul  5 21:38:49 2018 hochar_n
** Last update Thu Jul  5 21:38:51 2018 hochar_n
*/

#ifndef _MENU_H_
#define _MENU_H_

void main_menu(t_sdl *sdl);

#endif /* !_MENU_H_ */
