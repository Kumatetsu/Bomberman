/*
** main_loop.h for Project-Master in /home/enach/CLionProjects/Bomberman
**
** Made by hochar_n
** Login   <hochar_n@etna-alternance.net>
**
** Started on  Thu Jul  5 21:40:12 2018 hochar_n
** Last update Thu Jul  5 21:40:13 2018 hochar_n
*/

#ifndef _MAIN_LOOP_H_
#define _MAIN_LOOP_H_

int main_loop(t_srv **srv);

#endif /* !_MAIN_LOOP_H_ */
