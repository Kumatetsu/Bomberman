#ifndef _COORD_INDEX_SWAPPER_H_
#define _COORD_INDEX_SWAPPER_H_

int	index_to_x(int index);
int	index_to_y(int index);
int	coord_to_index(int x, int y);

#endif /* !_COORD_INDEX_SWAPPER_H_ */
