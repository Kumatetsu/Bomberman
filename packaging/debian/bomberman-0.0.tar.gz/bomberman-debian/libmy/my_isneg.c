/*
** my_isneg.c for libmy_finale in /home/aurelien/repertoire_rendu/piscine_C
**
** Made by CASTELLARNAU Aurelien
** Login   <castel_a@etna-alternance.net>
**
** Started on  Sat Oct 22 19:56:55 2016 CASTELLARNAU Aurelien
** Last update Wed Nov 16 10:55:55 2016 CASTELLARNAU Aurelien
*/

int	my_isneg(int n)
{
  return (n >= 0);
}
